//package br.com.example.gerenciamento.negocios;
//import br.com.example.gerenciamento.dados.*;
//import br.com.example.gerenciamento.excecoes.InsertException;
//import br.com.example.gerenciamento.excecoes.SelectException;
//
//public class Principal {
//	public static void main(String[] args) throws SelectException, InsertException {
//		Sistema sistema = Sistema.getInstance();
//		Bloco bloco = new Bloco(1, null, null);
//		Quadra quadra = new Quadra(1, "abc", "def", bloco);
//		sistema.insereQuadra(quadra);
//	}
//
//}
